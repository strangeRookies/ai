from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np


def save_confusion_matrix(cm: list[list[int]], output_path: Path, title: str = "Confusion Matrix") -> None:
    arr = np.asarray(cm)
    fig, ax = plt.subplots(figsize=(4, 4))
    image = ax.imshow(arr, cmap="Blues")
    ax.set_title(title)
    ax.set_xticks([0, 1], labels=["Normal", "Fall"])
    ax.set_yticks([0, 1], labels=["Normal", "Fall"])
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
    for i in range(arr.shape[0]):
        for j in range(arr.shape[1]):
            ax.text(j, i, str(arr[i, j]), ha="center", va="center", color="black")
    fig.colorbar(image, ax=ax, fraction=0.046, pad=0.04)
    fig.tight_layout()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=160)
    plt.close(fig)

