import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, confusion_matrix, precision_recall_fscore_support


def compute_binary_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict[str, float | int | list[list[int]]]:
    labels = [0, 1]
    cm = confusion_matrix(y_true, y_pred, labels=labels)
    tn, fp, fn, tp = cm.ravel() if cm.size == 4 else (0, 0, 0, 0)
    precision, recall, f1, _ = precision_recall_fscore_support(
        y_true, y_pred, labels=[1], average="binary", zero_division=0
    )
    false_alarm_rate = fp / (fp + tn) if (fp + tn) else 0.0
    miss_rate = fn / (fn + tp) if (fn + tp) else 0.0
    return {
        "accuracy": float(accuracy_score(y_true, y_pred)) if len(y_true) else 0.0,
        "precision": float(precision),
        "recall": float(recall),
        "f1": float(f1),
        "fall_recall": float(recall),
        "false_alarm_rate": float(false_alarm_rate),
        "miss_rate": float(miss_rate),
        "tn": int(tn),
        "fp": int(fp),
        "fn": int(fn),
        "tp": int(tp),
        "confusion_matrix": cm.astype(int).tolist(),
    }


def save_metric_tables(df: pd.DataFrame, output_dir: Path) -> dict[str, dict]:
    output_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    metrics: dict[str, dict] = {}
    scopes = [("overall", df)]
    scopes.extend((domain, sub_df) for domain, sub_df in df.groupby("domain"))
    for name, sub_df in scopes:
        values = compute_binary_metrics(sub_df["label"].to_numpy(), sub_df["pred"].to_numpy())
        metrics[name] = values
        row = {"scope": name}
        row.update({k: v for k, v in values.items() if k != "confusion_matrix"})
        rows.append(row)
    pd.DataFrame(rows).to_csv(output_dir / "results.csv", index=False)
    (output_dir / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    return metrics

