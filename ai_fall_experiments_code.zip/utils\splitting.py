import random

import pandas as pd


def assign_splits(df: pd.DataFrame, train_ratio: float, val_ratio: float, seed: int, group_by_source: bool) -> pd.DataFrame:
    df = df.copy()
    if "split" in df.columns and df["split"].notna().all():
        return df
    rng = random.Random(seed)
    group_col = "source_video" if group_by_source and "source_video" in df.columns else "clip_id"
    groups = list(df[group_col].drop_duplicates())
    rng.shuffle(groups)
    train_end = int(len(groups) * train_ratio)
    val_end = train_end + int(len(groups) * val_ratio)
    split_map = {}
    for group in groups[:train_end]:
        split_map[group] = "train"
    for group in groups[train_end:val_end]:
        split_map[group] = "val"
    for group in groups[val_end:]:
        split_map[group] = "test"
    df["split"] = df[group_col].map(split_map)
    return df


def experiment_train_filter(df: pd.DataFrame, experiment: dict, seed: int) -> pd.DataFrame:
    train_df = df[(df["split"] == "train") & (df["domain"].isin(experiment["train_domains"]))].copy()
    fraction = float(experiment.get("chromakey_fraction", 1.0))
    if "indoor_chromakey" in experiment["train_domains"] and fraction < 1.0:
        chroma = train_df[train_df["domain"] == "indoor_chromakey"]
        keep_n = int(round(len(chroma) * fraction))
        keep_chroma = chroma.sample(n=keep_n, random_state=seed) if keep_n > 0 else chroma.iloc[0:0]
        train_df = pd.concat([train_df[train_df["domain"] != "indoor_chromakey"], keep_chroma], ignore_index=True)
    return train_df.sample(frac=1.0, random_state=seed).reset_index(drop=True)

