# AI Fall Experiments

Linux GPU 서버에서 실신(Fall) 데이터셋을 clip 단위로 만들고, YOLO Pose keypoint sequence를 추출한 뒤 PyTorch LSTM baseline으로 Fall/Normal을 학습, 검증, 수치화하는 실험용 파이프라인입니다.

이 프로젝트는 RTSP 실시간 서비스, 백엔드, 프론트엔드, MQTT/Redis 연동을 포함하지 않습니다. 지금 단계의 목적은 재현 가능한 CLI 학습/비교 파이프라인입니다.

## Why Pose + LSTM

YOLO bbox만으로는 사람이 넘어지는 동작의 시간적 변화, 관절 자세, 신체 중심 이동을 충분히 설명하기 어렵습니다. 특히 쓰러짐은 한 프레임의 위치보다 여러 프레임에 걸친 자세 변화가 중요합니다. 그래서 이 파이프라인은 YOLO Pose로 각 clip의 keypoint sequence를 만들고, LSTM이 시간축 패턴을 학습하도록 구성합니다.

추후에는 같은 metadata/keypoint 구조 위에 ST-GCN, GNN, Video Classification 모델을 추가할 수 있습니다.

## Dataset Domains

기본 domain은 3개입니다.

- `indoor_background`: 실내 배경 데이터
- `indoor_chromakey`: 실내 크로마키 데이터
- `outdoor`: 실외 데이터

크로마키는 실제 CCTV와 도메인 차이가 있으므로 보조 데이터로 취급합니다. 평가는 항상 전체와 domain별로 따로 산출합니다.

기본 raw 데이터 위치는 `configs/fall_lstm.yaml`에서 설정합니다.

```text
data/raw/indoor_background/videos
data/raw/indoor_background/json
data/raw/indoor_chromakey/videos
data/raw/indoor_chromakey/json
data/raw/outdoor/videos
data/raw/outdoor/json
```

서버 기본 루트는 `/home/welabs/yolo_training/ai_fall_experiments`입니다.

## Setup

```bash
cd /home/welabs/yolo_training/ai_fall_experiments
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python - <<'PY'
import torch
print("cuda:", torch.cuda.is_available())
print("device:", torch.cuda.get_device_name(0) if torch.cuda.is_available() else "cpu")
PY
```

## 1. Prepare Clips

```bash
python scripts/prepare_clips.py --config configs/fall_lstm.yaml
```

기본값은 `clip_len=32`, `stride=8`입니다. annotation XML/JSON에 `event_frame`, `event_class`, `fall_intervals`, `fall_segments`, `events`, `start_frame/end_frame`류의 Fall 구간이 있으면 clip 라벨 생성에 사용합니다.

clip과 Fall 구간이 50% 이상 겹치면 `Fall`, Fall 구간 밖이면 `Normal`입니다. 애매한 overlap은 기본적으로 제외합니다. bbox 라벨이 없으면 detection 학습을 시도하지 않고 `dataset_check.json`에 pose 기반 분류 모드로 기록합니다.

XML 구조를 먼저 확인하려면 다음처럼 도메인별 샘플을 요약합니다.

```bash
python scripts/inspect_annotations.py \
  --config configs/fall_lstm.yaml \
  --samples-per-domain 2 \
  --output data/metadata/xml_annotation_inspection.json
```

전체 데이터를 돌리기 전 smoke test:

```bash
python scripts/prepare_clips.py \
  --config configs/fall_lstm.yaml \
  --max-videos-per-domain 2 \
  --no-save-clips \
  --metadata-output data/metadata/metadata_smoke.csv
```

결과:

```text
data/metadata/metadata.csv
data/metadata/dataset_check.json
data/processed/clips/{domain}/*.mp4
```

## 2. Extract YOLO Pose Keypoints

```bash
python scripts/extract_keypoints_yolo_pose.py --config configs/fall_lstm.yaml
```

기본 모델은 `yolo11n-pose.pt`입니다. 각 clip은 `[T,V,C]` 형태로 저장됩니다.

- `T`: frame count
- `V`: keypoint count
- `C`: `x,y,confidence`

사람이 여러 명이면 기본적으로 가장 큰 bbox의 사람을 선택합니다. 누락된 프레임은 이전 프레임으로 보간하며, config에서 zero padding으로 변경할 수 있습니다.

결과:

```text
data/keypoints/{domain}/*.npz
```

모델과 저장 위치를 직접 바꿀 수도 있습니다.

```bash
python scripts/extract_keypoints_yolo_pose.py \
  --config configs/fall_lstm.yaml \
  --pose-model yolov8n-pose.pt \
  --output-dir data/keypoints/yolov8n-pose
```

## 3. Compare YOLO Pose Models

다음 6개 모델을 같은 clip metadata로 순서대로 비교합니다.

- `yolov8n-pose.pt`
- `yolov8s-pose.pt`
- `yolo11n-pose.pt`
- `yolo11s-pose.pt`
- `yolo26n-pose.pt`
- `yolo26s-pose.pt`

실행:

```bash
bash scripts/run_pose_model_compare.sh
python scripts/summarize_pose_models.py --runs runs/pose_compare
```

모델 파일이 자동 다운로드되지 않거나 존재하지 않으면 해당 모델은 `status=failed`로 기록하고 다음 모델로 넘어갑니다.

모델별 결과:

```text
data/keypoints/yolov8n-pose/
data/keypoints/yolov8s-pose/
data/keypoints/yolo11n-pose/
data/keypoints/yolo11s-pose/
data/keypoints/yolo26n-pose/
data/keypoints/yolo26s-pose/
```

모델별 로그와 메트릭:

```text
runs/pose_compare/<model_name>/extract.log
runs/pose_compare/<model_name>/pose_metrics.json
runs/pose_compare/<model_name>/pose_metrics.csv
runs/pose_compare/pose_compare.log
runs/pose_compare/pose_model_summary.csv
```

`pose_model_summary.csv`에는 최소 다음 컬럼이 포함됩니다.

```text
model,status,processed_clips,failed_clips,total_frames,total_time_sec,avg_fps,avg_inference_ms,output_dir,error_message
```

tmux 실행 예시:

```bash
tmux new -s pose_compare
cd /home/welabs/yolo_training/ai_fall_experiments
source .venv/bin/activate
bash scripts/run_pose_model_compare.sh
```

detach:

```text
Ctrl+B 후 D
```

reattach:

```bash
tmux attach -t pose_compare
```

nohup 실행 예시:

```bash
nohup bash scripts/run_pose_model_compare.sh > runs/pose_compare_nohup.log 2>&1 &
tail -f runs/pose_compare_nohup.log
```

## 4. Train LSTM

```bash
python scripts/train_lstm.py --config configs/fall_lstm.yaml --experiment indoor_outdoor
```

입력은 `[batch, seq_len, feature_dim]`이고 `feature_dim=keypoint_count*3`입니다. 기본 모델은 `hidden_size=128`, `num_layers=2`, `dropout=0.3`입니다. CUDA가 가능하면 `cuda:0`을 사용하고, 아니면 CPU 경고 후 실행합니다.

결과:

```text
runs/lstm/indoor_outdoor/best.pt
runs/lstm/indoor_outdoor/train.log
runs/lstm/indoor_outdoor/splits.csv
```

## 5. Evaluate

```bash
python scripts/eval_lstm.py --config configs/fall_lstm.yaml --checkpoint runs/lstm/indoor_outdoor/best.pt
```

산출 지표:

- Accuracy
- Precision
- Recall
- F1
- Confusion Matrix
- Fall Recall
- False Alarm Rate
- Miss Rate

전체 테스트와 domain별 테스트를 모두 저장합니다. GUI 없는 서버 환경을 위해 matplotlib `Agg` backend를 사용합니다.

결과:

```text
runs/lstm/indoor_outdoor/results.csv
runs/lstm/indoor_outdoor/metrics.json
runs/lstm/indoor_outdoor/confusion_matrix.png
runs/lstm/indoor_outdoor/predictions.csv
```

## Experiments

`configs/experiments.yaml`에는 3개 실험이 정의되어 있습니다.

- `indoor_outdoor`: A. 실내 배경 + 실외 학습, 현실 CCTV baseline
- `all_domains`: B. 실내 배경 + 실외 + 크로마키 전체 학습
- `partial_chromakey`: C. 실내 배경 + 실외 + 크로마키 일부 학습

전체 실행:

```bash
bash scripts/run_experiments.sh
python scripts/summarize_results.py --runs runs/lstm
```

요약 결과:

```text
runs/lstm/summary.csv
```

## Long Running LSTM Jobs

```bash
tmux new -s fall_train
cd /home/welabs/yolo_training/ai_fall_experiments
source .venv/bin/activate
bash scripts/run_experiments.sh
```

detach:

```text
Ctrl+B 후 D
```

reattach:

```bash
tmux attach -t fall_train
```

nohup 예시:

```bash
nohup bash scripts/run_experiments.sh > runs/lstm/nohup.log 2>&1 &
tail -f runs/lstm/nohup.log
```

## Extension Plan

현재 구조는 `metadata.csv`와 `[T,V,C]` keypoint 파일을 중심으로 되어 있어 다음 확장이 쉽습니다.

- ST-GCN: keypoint graph adjacency와 temporal graph convolution 추가
- GNN: 사람 skeleton node/edge feature 기반 graph classifier 추가
- Video Classification: clip mp4를 직접 입력하는 3D CNN, TimeSformer, VideoMAE 계열 추가
- Multi-person policy: largest bbox 외 tracking 기반 subject selection 추가
- Domain generalization: 크로마키 보조 데이터 비율 sweep, domain별 calibration 비교
