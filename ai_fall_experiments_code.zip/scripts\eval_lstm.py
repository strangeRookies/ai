import argparse
import sys
from pathlib import Path

import pandas as pd
import torch
from torch.utils.data import DataLoader

sys.path.append(str(Path(__file__).resolve().parents[1]))

from models.lstm_classifier import LSTMClassifier
from utils.config import load_yaml, project_path
from utils.dataset import KeypointSequenceDataset
from utils.metrics import save_metric_tables
from utils.splitting import assign_splits
from utils.visualization import save_confusion_matrix


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate LSTM fall classifier.")
    parser.add_argument("--config", required=True)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--split", default="test")
    args = parser.parse_args()

    config = load_yaml(args.config)
    checkpoint_path = Path(args.checkpoint)
    ckpt = torch.load(checkpoint_path, map_location="cpu")
    run_dir = checkpoint_path.parent
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    if device.type == "cpu":
        print("[eval] WARNING: CUDA is not available. Running on CPU.")

    metadata_csv = project_path(config, config["paths"]["metadata_csv"])
    df = pd.read_csv(metadata_csv)
    df = assign_splits(
        df,
        config["split"]["train_ratio"],
        config["split"]["val_ratio"],
        config["seed"],
        config["split"].get("group_by_source", True),
    )
    keypoint_mask = df["keypoint_path"].notna() & (df["keypoint_path"].astype(str).str.lower() != "nan")
    keypoint_mask &= df["keypoint_path"].astype(str).str.len() > 0
    test_df = df[(df["split"] == args.split) & keypoint_mask].copy()
    if len(test_df) == 0:
        raise RuntimeError(f"No rows found for split={args.split}")

    model = LSTMClassifier(
        input_size=int(ckpt["feature_dim"]),
        hidden_size=config["train"]["hidden_size"],
        num_layers=config["train"]["num_layers"],
        dropout=config["train"]["dropout"],
    )
    model.load_state_dict(ckpt["model_state"])
    model.to(device)
    model.eval()

    loader = DataLoader(
        KeypointSequenceDataset(test_df, int(ckpt["seq_len"])),
        batch_size=config["train"]["batch_size"],
        shuffle=False,
        num_workers=config["train"]["num_workers"],
    )
    probs = []
    preds = []
    with torch.no_grad():
        for x, _ in loader:
            logits = model(x.to(device))
            batch_probs = torch.softmax(logits, dim=1)[:, 1].detach().cpu()
            probs.extend(batch_probs.numpy().tolist())
            preds.extend((batch_probs >= float(config["eval"]["threshold"])).long().numpy().tolist())

    result_df = test_df.copy()
    result_df["fall_probability"] = probs
    result_df["pred"] = preds
    result_df["pred_name"] = result_df["pred"].map({0: "Normal", 1: "Fall"})
    result_df.to_csv(run_dir / "predictions.csv", index=False)
    metrics = save_metric_tables(result_df, run_dir)
    save_confusion_matrix(metrics["overall"]["confusion_matrix"], run_dir / "confusion_matrix.png")
    print(f"[eval] saved results to {run_dir}")


if __name__ == "__main__":
    main()
