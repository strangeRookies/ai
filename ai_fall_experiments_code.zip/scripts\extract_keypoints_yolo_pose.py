import argparse
import csv
import json
import sys
import time
from pathlib import Path

import cv2
import numpy as np
import pandas as pd
import torch
from tqdm import tqdm

sys.path.append(str(Path(__file__).resolve().parents[1]))

from utils.config import load_yaml, project_path


def select_person(result, policy: str) -> int | None:
    if result.keypoints is None or result.keypoints.data is None or len(result.keypoints.data) == 0:
        return None
    boxes = result.boxes
    if boxes is None or boxes.xyxy is None:
        return 0
    if policy == "highest_confidence" and boxes.conf is not None:
        return int(torch.argmax(boxes.conf).item())
    xyxy = boxes.xyxy
    areas = (xyxy[:, 2] - xyxy[:, 0]).clamp(min=0) * (xyxy[:, 3] - xyxy[:, 1]).clamp(min=0)
    return int(torch.argmax(areas).item())


def fill_missing(sequence: np.ndarray, policy: str) -> np.ndarray:
    if policy == "zero":
        return sequence
    last = None
    for i in range(sequence.shape[0]):
        if np.count_nonzero(sequence[i]) == 0 and last is not None:
            sequence[i] = last
        elif np.count_nonzero(sequence[i]) > 0:
            last = sequence[i].copy()
    return sequence


def extract_clip_keypoints(model, clip_path: Path, pose_cfg: dict) -> tuple[np.ndarray, int, float]:
    cap = cv2.VideoCapture(str(clip_path))
    frames = []
    inference_time_sec = 0.0
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        start = time.perf_counter()
        result = model.predict(
            source=frame,
            imgsz=pose_cfg["imgsz"],
            conf=pose_cfg["conf"],
            device=None if pose_cfg["device"] == "auto" else pose_cfg["device"],
            verbose=False,
        )[0]
        inference_time_sec += time.perf_counter() - start
        person_idx = select_person(result, pose_cfg["person_select"])
        if person_idx is None:
            frames.append(None)
        else:
            keypoints = result.keypoints.data[person_idx].detach().cpu().numpy().astype(np.float32)
            frames.append(keypoints)
    cap.release()
    if not frames:
        return np.zeros((0, 17, 3), dtype=np.float32), 0, inference_time_sec
    keypoint_count = next((frame.shape[0] for frame in frames if frame is not None), 17)
    sequence = np.zeros((len(frames), keypoint_count, 3), dtype=np.float32)
    for idx, frame in enumerate(frames):
        if frame is not None:
            sequence[idx, : frame.shape[0], : frame.shape[1]] = frame[:, :3]
    return fill_missing(sequence, pose_cfg["missing_policy"]), len(frames), inference_time_sec


def write_metrics(metrics: dict, json_path: Path | None, csv_path: Path | None) -> None:
    if json_path is not None:
        json_path.parent.mkdir(parents=True, exist_ok=True)
        json_path.write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    if csv_path is not None:
        csv_path.parent.mkdir(parents=True, exist_ok=True)
        with csv_path.open("w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(metrics.keys()))
            writer.writeheader()
            writer.writerow(metrics)


def main() -> None:
    parser = argparse.ArgumentParser(description="Extract YOLO pose keypoints for clips.")
    parser.add_argument("--config", required=True)
    parser.add_argument("--metadata", default=None)
    parser.add_argument("--pose-model", default=None)
    parser.add_argument("--output-dir", default=None)
    parser.add_argument("--metrics-output", default=None)
    parser.add_argument("--metrics-csv-output", default=None)
    parser.add_argument("--no-update-metadata", action="store_true")
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()

    from ultralytics import YOLO

    config = load_yaml(args.config)
    metadata_csv = Path(args.metadata) if args.metadata else project_path(config, config["paths"]["metadata_csv"])
    pose_cfg = config["pose"]
    pose_cfg["model"] = args.pose_model or pose_cfg["model"]
    if args.output_dir:
        keypoints_dir = project_path(config, args.output_dir)
    else:
        keypoints_dir = project_path(config, config["paths"]["keypoints_dir"])
    metrics_json = project_path(config, args.metrics_output) if args.metrics_output else None
    metrics_csv = project_path(config, args.metrics_csv_output) if args.metrics_csv_output else None
    keypoints_dir.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(metadata_csv)
    started_at = time.strftime("%Y-%m-%dT%H:%M:%S%z")
    wall_start = time.perf_counter()
    model_name = Path(pose_cfg["model"]).stem
    base_metrics = {
        "model": model_name,
        "status": "running",
        "started_at": started_at,
        "ended_at": "",
        "processed_clips": 0,
        "failed_clips": 0,
        "total_frames": 0,
        "total_time_sec": 0.0,
        "avg_fps": 0.0,
        "avg_inference_ms": 0.0,
        "output_dir": str(keypoints_dir),
        "error_message": "",
    }
    try:
        model = YOLO(pose_cfg["model"])
    except Exception as exc:
        base_metrics.update(
            {
                "status": "failed",
                "ended_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                "total_time_sec": round(time.perf_counter() - wall_start, 4),
                "error_message": str(exc),
            }
        )
        write_metrics(base_metrics, metrics_json, metrics_csv)
        print(f"[extract] failed to load model={pose_cfg['model']}: {exc}")
        raise SystemExit(1)

    keypoint_paths = []
    total_frames = 0
    total_inference_sec = 0.0
    processed_clips = 0
    failed_clips = 0
    errors = []
    for row in tqdm(df.itertuples(index=False), total=len(df), desc="extract keypoints"):
        clip_path = Path(row.clip_path)
        out_dir = keypoints_dir / row.domain
        out_dir.mkdir(parents=True, exist_ok=True)
        out_path = out_dir / f"{row.clip_id}.{pose_cfg['save_format']}"
        try:
            if args.overwrite or not out_path.exists():
                sequence, frame_count, inference_sec = extract_clip_keypoints(model, clip_path, pose_cfg)
                if pose_cfg["save_format"] == "npy":
                    np.save(out_path, sequence)
                else:
                    np.savez_compressed(out_path, keypoints=sequence)
            else:
                if out_path.suffix == ".npy":
                    sequence = np.load(out_path)
                else:
                    with np.load(out_path) as data:
                        sequence = data["keypoints"]
                frame_count = int(sequence.shape[0])
                inference_sec = 0.0
            keypoint_paths.append(str(out_path))
            processed_clips += 1
            total_frames += int(frame_count)
            total_inference_sec += float(inference_sec)
        except Exception as exc:
            failed_clips += 1
            errors.append(f"{clip_path}: {exc}")
            keypoint_paths.append("")
            print(f"[extract] failed clip={clip_path}: {exc}")
    if not args.no_update_metadata:
        df["keypoint_path"] = keypoint_paths
        df.to_csv(metadata_csv, index=False)

    total_time_sec = time.perf_counter() - wall_start
    status = "success" if failed_clips == 0 else "partial_success"
    metrics = {
        "model": model_name,
        "status": status,
        "started_at": started_at,
        "ended_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "processed_clips": processed_clips,
        "failed_clips": failed_clips,
        "total_frames": total_frames,
        "total_time_sec": round(total_time_sec, 4),
        "avg_fps": round(total_frames / total_time_sec, 4) if total_time_sec > 0 else 0.0,
        "avg_inference_ms": round((total_inference_sec / total_frames) * 1000.0, 4) if total_frames > 0 else 0.0,
        "output_dir": str(keypoints_dir),
        "error_message": " | ".join(errors[:5]),
    }
    write_metrics(metrics, metrics_json, metrics_csv)
    if args.no_update_metadata:
        print(f"[extract] metadata left unchanged: {metadata_csv}")
    else:
        print(f"[extract] updated metadata: {metadata_csv}")
    if failed_clips:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
