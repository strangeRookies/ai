from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset


class KeypointSequenceDataset(Dataset):
    def __init__(self, metadata: pd.DataFrame, seq_len: int) -> None:
        self.metadata = metadata.reset_index(drop=True)
        self.seq_len = seq_len

    def __len__(self) -> int:
        return len(self.metadata)

    def __getitem__(self, index: int) -> tuple[torch.Tensor, torch.Tensor]:
        row = self.metadata.iloc[index]
        keypoints = load_keypoints(Path(row["keypoint_path"]))
        keypoints = resize_sequence(keypoints, self.seq_len)
        features = keypoints.reshape(keypoints.shape[0], -1).astype(np.float32)
        return torch.from_numpy(features), torch.tensor(int(row["label"]), dtype=torch.long)


def load_keypoints(path: Path) -> np.ndarray:
    if path.suffix == ".npy":
        arr = np.load(path)
    else:
        with np.load(path) as data:
            arr = data["keypoints"]
    if arr.ndim != 3:
        raise ValueError(f"Expected [T,V,C] keypoints, got shape={arr.shape} path={path}")
    return arr.astype(np.float32)


def resize_sequence(sequence: np.ndarray, seq_len: int) -> np.ndarray:
    if sequence.shape[0] == seq_len:
        return sequence
    if sequence.shape[0] == 0:
        return np.zeros((seq_len, 17, 3), dtype=np.float32)
    if sequence.shape[0] > seq_len:
        return sequence[:seq_len]
    pad = np.repeat(sequence[-1:, :, :], seq_len - sequence.shape[0], axis=0)
    return np.concatenate([sequence, pad], axis=0)


def infer_feature_dim(metadata: pd.DataFrame, seq_len: int) -> int:
    for path in metadata["keypoint_path"]:
        if isinstance(path, str) and path:
            keypoints = resize_sequence(load_keypoints(Path(path)), seq_len)
            return int(keypoints.reshape(keypoints.shape[0], -1).shape[1])
    raise ValueError("No keypoint_path found in metadata.")

