import argparse
import json
from pathlib import Path

import pandas as pd


SUMMARY_COLUMNS = [
    "model",
    "status",
    "processed_clips",
    "failed_clips",
    "total_frames",
    "total_time_sec",
    "avg_fps",
    "avg_inference_ms",
    "output_dir",
    "error_message",
]


def main() -> None:
    parser = argparse.ArgumentParser(description="Summarize YOLO Pose model extraction metrics.")
    parser.add_argument("--runs", required=True)
    args = parser.parse_args()

    runs_dir = Path(args.runs)
    rows = []
    for metrics_path in sorted(runs_dir.glob("*/pose_metrics.json")):
        data = json.loads(metrics_path.read_text(encoding="utf-8"))
        row = {column: data.get(column, "") for column in SUMMARY_COLUMNS}
        rows.append(row)
    if not rows:
        raise RuntimeError(f"No pose_metrics.json found under {runs_dir}")

    output = runs_dir / "pose_model_summary.csv"
    pd.DataFrame(rows, columns=SUMMARY_COLUMNS).to_csv(output, index=False)
    print(f"[summary] saved {output}")


if __name__ == "__main__":
    main()

