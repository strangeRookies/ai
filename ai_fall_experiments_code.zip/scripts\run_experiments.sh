#!/usr/bin/env bash
set -euo pipefail

CONFIG="${CONFIG:-configs/fall_lstm.yaml}"
EXPERIMENTS=(indoor_outdoor all_domains partial_chromakey)

for EXPERIMENT in "${EXPERIMENTS[@]}"; do
  echo "[run] training ${EXPERIMENT}"
  python scripts/train_lstm.py --config "${CONFIG}" --experiment "${EXPERIMENT}"
  echo "[run] evaluating ${EXPERIMENT}"
  python scripts/eval_lstm.py --config "${CONFIG}" --checkpoint "runs/lstm/${EXPERIMENT}/best.pt"
done

python scripts/summarize_results.py --runs runs/lstm

