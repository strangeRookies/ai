import argparse
import csv
import json
import sys
from pathlib import Path
from xml.etree import ElementTree as ET

import pandas as pd

sys.path.append(str(Path(__file__).resolve().parents[1]))

from utils.config import load_yaml, project_path
from utils.labeling import label_clip, load_fall_intervals
from utils.video_io import video_info, write_clip


def find_annotation(video_path: Path, annotation_dir: Path, extensions: list[str]) -> Path | None:
    for ext in extensions:
        candidate = annotation_dir / f"{video_path.stem}{ext}"
        if candidate.exists():
            return candidate
    for ext in extensions:
        matches = sorted(annotation_dir.rglob(f"{video_path.stem}{ext}"))
        if matches:
            return matches[0]
    return None


def annotation_has_bbox(annotation_path: Path | None) -> bool:
    if annotation_path is None or not annotation_path.exists():
        return False
    if annotation_path.suffix.lower() == ".xml":
        try:
            root = ET.parse(annotation_path).getroot()
        except ET.ParseError:
            return False
        encoded = " ".join([elem.tag.lower() for elem in root.iter()])
        encoded += " " + " ".join(
            f"{key.lower()} {value.lower()}" for elem in root.iter() for key, value in elem.attrib.items()
        )
        return any(key in encoded for key in ("bbox", "bndbox", "bounding_box", "xmin", "ymin", "xmax", "ymax"))
    try:
        data = json.loads(annotation_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return False
    encoded = json.dumps(data).lower()
    return any(key in encoded for key in ("bbox", "bounding_box", "box2d", "x_min", "y_min"))


def iter_videos(video_dir: Path, extensions: list[str]) -> list[Path]:
    videos: list[Path] = []
    for ext in extensions:
        videos.extend(video_dir.rglob(f"*{ext}"))
        videos.extend(video_dir.rglob(f"*{ext.upper()}"))
    return sorted(set(videos))


def main() -> None:
    parser = argparse.ArgumentParser(description="Create fall/normal clips and metadata.")
    parser.add_argument("--config", required=True)
    parser.add_argument("--no-save-clips", action="store_true")
    parser.add_argument("--project-root", default=None, help="Override project_root from config.")
    parser.add_argument("--metadata-output", default=None, help="Override metadata CSV output path.")
    parser.add_argument("--max-videos-per-domain", type=int, default=None, help="Limit videos per domain for smoke tests.")
    parser.add_argument("--domains", nargs="*", default=None, help="Optional domain names to process.")
    args = parser.parse_args()

    config = load_yaml(args.config)
    if args.project_root:
        config["project_root"] = args.project_root
    clip_cfg = config["clip"]
    paths = config["paths"]
    metadata_csv = project_path(config, args.metadata_output or paths["metadata_csv"])
    clips_dir = project_path(config, paths["clips_dir"])
    metadata_csv.parent.mkdir(parents=True, exist_ok=True)
    clips_dir.mkdir(parents=True, exist_ok=True)

    rows: list[dict] = []
    bbox_count = 0
    video_count = 0

    for domain, domain_cfg in config["domains"].items():
        if args.domains and domain not in args.domains:
            continue
        video_dir = project_path(config, domain_cfg["video_dir"])
        annotation_dir = project_path(config, domain_cfg["annotation_dir"])
        videos = iter_videos(video_dir, clip_cfg["video_extensions"])
        if args.max_videos_per_domain is not None:
            videos = videos[: args.max_videos_per_domain]
        print(f"[prepare] domain={domain} videos={len(videos)} video_dir={video_dir}")
        for video_path in videos:
            video_count += 1
            annotation_path = find_annotation(video_path, annotation_dir, clip_cfg["annotation_extensions"])
            intervals = load_fall_intervals(annotation_path)
            has_bbox = annotation_has_bbox(annotation_path)
            bbox_count += int(has_bbox)
            frame_count, fps, width, height = video_info(video_path)
            last_start = max(0, frame_count - clip_cfg["clip_len"])
            for start in range(0, last_start + 1, clip_cfg["stride"]):
                end = start + clip_cfg["clip_len"] - 1
                if end >= frame_count:
                    break
                label = label_clip(
                    start,
                    end,
                    intervals,
                    clip_cfg["min_fall_overlap"],
                    clip_cfg["normal_max_event_overlap"],
                    clip_cfg["ambiguous_policy"],
                )
                if label is None:
                    continue
                clip_name = f"{domain}__{video_path.stem}__{start:06d}_{end:06d}.mp4"
                clip_path = clips_dir / domain / clip_name
                if clip_cfg.get("save_video_clips", True) and not args.no_save_clips:
                    write_clip(video_path, clip_path, start, end, fps, width, height)
                rows.append(
                    {
                        "clip_id": clip_path.stem,
                        "clip_path": str(clip_path),
                        "keypoint_path": "",
                        "label": label,
                        "label_name": "Fall" if label == 1 else "Normal",
                        "domain": domain,
                        "source_video": str(video_path),
                        "annotation_path": str(annotation_path) if annotation_path else "",
                        "start_frame": start,
                        "end_frame": end,
                        "fps": fps,
                        "width": width,
                        "height": height,
                        "has_bbox_label": has_bbox,
                        "fall_intervals": json.dumps(intervals),
                    }
                )

    if not rows:
        print("[prepare] no clips were generated. Check raw data paths and annotation schema.")
    pd.DataFrame(rows).to_csv(metadata_csv, index=False, quoting=csv.QUOTE_MINIMAL)
    mode = "pose_keypoint_classification" if bbox_count == 0 else "pose_keypoint_classification_bbox_available"
    summary = {
        "videos": video_count,
        "clips": len(rows),
        "videos_with_bbox_labels": bbox_count,
        "recommended_mode": mode,
        "metadata_csv": str(metadata_csv),
    }
    (metadata_csv.parent / "dataset_check.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
