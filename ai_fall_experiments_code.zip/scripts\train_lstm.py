import argparse
import json
import logging
import random
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.utils.data import DataLoader

sys.path.append(str(Path(__file__).resolve().parents[1]))

from models.lstm_classifier import LSTMClassifier
from utils.config import load_yaml, project_path
from utils.dataset import KeypointSequenceDataset, infer_feature_dim
from utils.splitting import assign_splits, experiment_train_filter


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def setup_logger(log_path: Path) -> logging.Logger:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("train_lstm")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    formatter = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
    stream = logging.StreamHandler()
    stream.setFormatter(formatter)
    file_handler = logging.FileHandler(log_path, encoding="utf-8")
    file_handler.setFormatter(formatter)
    logger.addHandler(stream)
    logger.addHandler(file_handler)
    return logger


def make_class_weight(labels: pd.Series, device: torch.device) -> torch.Tensor | None:
    counts = labels.value_counts().to_dict()
    if not counts or len(counts) < 2:
        return None
    total = sum(counts.values())
    weights = [total / max(1, 2 * counts.get(cls, 0)) for cls in (0, 1)]
    return torch.tensor(weights, dtype=torch.float32, device=device)


def run_epoch(model, loader, criterion, optimizer, device, train: bool) -> tuple[float, float]:
    model.train(train)
    total_loss = 0.0
    correct = 0
    total = 0
    for x, y in loader:
        x = x.to(device)
        y = y.to(device)
        with torch.set_grad_enabled(train):
            logits = model(x)
            loss = criterion(logits, y)
            if train:
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
        total_loss += float(loss.item()) * y.size(0)
        correct += int((logits.argmax(dim=1) == y).sum().item())
        total += int(y.size(0))
    return total_loss / max(1, total), correct / max(1, total)


def main() -> None:
    parser = argparse.ArgumentParser(description="Train LSTM fall classifier from pose keypoints.")
    parser.add_argument("--config", required=True)
    parser.add_argument("--experiments-config", default="configs/experiments.yaml")
    parser.add_argument("--experiment", required=True)
    args = parser.parse_args()

    config = load_yaml(args.config)
    experiments = load_yaml(project_path(config, args.experiments_config))["experiments"]
    experiment = experiments[args.experiment]
    seed = int(config["seed"])
    set_seed(seed)

    run_dir = project_path(config, config["paths"]["runs_dir"]) / args.experiment
    logger = setup_logger(run_dir / "train.log")
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    if device.type == "cpu":
        logger.warning("CUDA is not available. Training will run on CPU.")
    else:
        logger.info("Using device %s: %s", device, torch.cuda.get_device_name(0))

    metadata_csv = project_path(config, config["paths"]["metadata_csv"])
    df = pd.read_csv(metadata_csv)
    keypoint_mask = df["keypoint_path"].notna() & (df["keypoint_path"].astype(str).str.lower() != "nan")
    keypoint_mask &= df["keypoint_path"].astype(str).str.len() > 0
    df = df[keypoint_mask].copy()
    if len(df) == 0:
        raise RuntimeError("No keypoint_path values found. Run extract_keypoints_yolo_pose.py first.")
    df = assign_splits(
        df,
        config["split"]["train_ratio"],
        config["split"]["val_ratio"],
        seed,
        config["split"].get("group_by_source", True),
    )
    df.to_csv(metadata_csv, index=False)

    train_df = experiment_train_filter(df, experiment, seed)
    val_df = df[(df["split"] == "val") & (df["domain"].isin(experiment.get("test_domains", df["domain"].unique())))].copy()
    if len(train_df) == 0 or len(val_df) == 0:
        raise RuntimeError(f"Empty split. train={len(train_df)} val={len(val_df)}")

    train_cfg = config["train"]
    seq_len = int(train_cfg["seq_len"])
    feature_dim = infer_feature_dim(train_df, seq_len)
    train_loader = DataLoader(
        KeypointSequenceDataset(train_df, seq_len),
        batch_size=train_cfg["batch_size"],
        shuffle=True,
        num_workers=train_cfg["num_workers"],
    )
    val_loader = DataLoader(
        KeypointSequenceDataset(val_df, seq_len),
        batch_size=train_cfg["batch_size"],
        shuffle=False,
        num_workers=train_cfg["num_workers"],
    )

    model = LSTMClassifier(
        input_size=feature_dim,
        hidden_size=train_cfg["hidden_size"],
        num_layers=train_cfg["num_layers"],
        dropout=train_cfg["dropout"],
    ).to(device)
    weights = make_class_weight(train_df["label"], device) if train_cfg.get("class_weight") == "balanced" else None
    criterion = nn.CrossEntropyLoss(weight=weights)
    optimizer = torch.optim.AdamW(model.parameters(), lr=train_cfg["lr"], weight_decay=train_cfg["weight_decay"])

    best_val = -1.0
    patience_left = int(train_cfg["early_stop_patience"])
    for epoch in range(1, int(train_cfg["epochs"]) + 1):
        train_loss, train_acc = run_epoch(model, train_loader, criterion, optimizer, device, True)
        val_loss, val_acc = run_epoch(model, val_loader, criterion, optimizer, device, False)
        logger.info(
            "epoch=%03d train_loss=%.5f train_acc=%.4f val_loss=%.5f val_acc=%.4f",
            epoch,
            train_loss,
            train_acc,
            val_loss,
            val_acc,
        )
        if val_acc > best_val:
            best_val = val_acc
            patience_left = int(train_cfg["early_stop_patience"])
            torch.save(
                {
                    "model_state": model.state_dict(),
                    "config": config,
                    "experiment": args.experiment,
                    "feature_dim": feature_dim,
                    "seq_len": seq_len,
                    "classes": {"Normal": 0, "Fall": 1},
                },
                run_dir / "best.pt",
            )
            logger.info("saved best checkpoint val_acc=%.4f", best_val)
        else:
            patience_left -= 1
            if patience_left <= 0:
                logger.info("early stopping")
                break

    split_path = run_dir / "splits.csv"
    pd.concat([train_df.assign(active_split="train"), val_df.assign(active_split="val")]).to_csv(split_path, index=False)
    (run_dir / "experiment.json").write_text(json.dumps(experiment, indent=2), encoding="utf-8")
    logger.info("done run_dir=%s", run_dir)


if __name__ == "__main__":
    main()
