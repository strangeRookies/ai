import argparse
import json
import sys
from collections import Counter
from pathlib import Path
from xml.etree import ElementTree as ET

sys.path.append(str(Path(__file__).resolve().parents[1]))

from utils.config import load_yaml, project_path
from utils.labeling import LABEL_KEYS, load_fall_intervals, normalize_key


def find_xml_files(annotation_dir: Path, limit: int) -> list[Path]:
    return sorted(annotation_dir.rglob("*.xml"))[:limit]


def summarize_xml(path: Path) -> dict:
    root = ET.parse(path).getroot()
    tag_counts = Counter(normalize_key(elem.tag) for elem in root.iter())
    attr_counts = Counter(normalize_key(key) for elem in root.iter() for key in elem.attrib)
    label_candidates = []
    frame_candidates = []

    for elem in root.iter():
        values = dict(elem.attrib)
        for child in list(elem):
            if child.text and child.text.strip():
                values[child.tag] = child.text.strip()
        for key, value in values.items():
            norm = normalize_key(key)
            if norm in LABEL_KEYS or "class" in norm or "label" in norm or "event" in norm:
                label_candidates.append({"field": key, "value": str(value)[:120]})
            if "frame" in norm or norm in {"start", "end", "begin"}:
                frame_candidates.append({"field": key, "value": str(value)[:120]})

    return {
        "file": str(path),
        "root_tag": root.tag,
        "top_tags": tag_counts.most_common(20),
        "top_attributes": attr_counts.most_common(20),
        "label_candidates": label_candidates[:20],
        "frame_candidates": frame_candidates[:20],
        "fall_intervals": load_fall_intervals(path),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Inspect XML annotation structure by domain.")
    parser.add_argument("--config", required=True)
    parser.add_argument("--project-root", default=None)
    parser.add_argument("--samples-per-domain", type=int, default=1)
    parser.add_argument("--output", default=None)
    args = parser.parse_args()

    config = load_yaml(args.config)
    if args.project_root:
        config["project_root"] = args.project_root

    summaries = {}
    for domain, domain_cfg in config["domains"].items():
        annotation_dir = project_path(config, domain_cfg["annotation_dir"])
        samples = find_xml_files(annotation_dir, args.samples_per_domain)
        summaries[domain] = [summarize_xml(path) for path in samples]
        print(f"[inspect] domain={domain} annotation_dir={annotation_dir} xml_samples={len(samples)}")
        for summary in summaries[domain]:
            print(json.dumps(summary, ensure_ascii=False, indent=2))

    if args.output:
        output = project_path(config, args.output)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(summaries, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"[inspect] saved {output}")


if __name__ == "__main__":
    main()

