#!/usr/bin/env bash
set -uo pipefail

CONFIG="${CONFIG:-configs/fall_lstm.yaml}"
RUNS_DIR="${RUNS_DIR:-runs/pose_compare}"
MODELS=(
  yolov8n-pose.pt
  yolov8s-pose.pt
  yolo11n-pose.pt
  yolo11s-pose.pt
  yolo26n-pose.pt
  yolo26s-pose.pt
)

mkdir -p "${RUNS_DIR}"
GLOBAL_LOG="${RUNS_DIR}/pose_compare.log"
touch "${GLOBAL_LOG}"

log_global() {
  echo "$1" | tee -a "${GLOBAL_LOG}"
}

log_global "[pose-compare] started_at=$(date -Is)"
log_global "[pose-compare] config=${CONFIG}"

for MODEL_FILE in "${MODELS[@]}"; do
  MODEL_NAME="${MODEL_FILE%.pt}"
  MODEL_RUN_DIR="${RUNS_DIR}/${MODEL_NAME}"
  OUTPUT_DIR="data/keypoints/${MODEL_NAME}"
  EXTRACT_LOG="${MODEL_RUN_DIR}/extract.log"
  METRICS_JSON="${MODEL_RUN_DIR}/pose_metrics.json"
  METRICS_CSV="${MODEL_RUN_DIR}/pose_metrics.csv"

  mkdir -p "${MODEL_RUN_DIR}"
  START_EPOCH=$(date +%s)
  START_ISO=$(date -Is)
  log_global "[pose-compare] model=${MODEL_NAME} status=started started_at=${START_ISO}"

  {
    echo "[extract] model=${MODEL_FILE}"
    echo "[extract] started_at=${START_ISO}"
    echo "[extract] output_dir=${OUTPUT_DIR}"
    python scripts/extract_keypoints_yolo_pose.py \
      --config "${CONFIG}" \
      --pose-model "${MODEL_FILE}" \
      --output-dir "${OUTPUT_DIR}" \
      --metrics-output "${METRICS_JSON}" \
      --metrics-csv-output "${METRICS_CSV}" \
      --no-update-metadata \
      --overwrite
  } > "${EXTRACT_LOG}" 2>&1
  EXIT_CODE=$?

  END_EPOCH=$(date +%s)
  END_ISO=$(date -Is)
  DURATION=$((END_EPOCH - START_EPOCH))

  if [ ! -f "${METRICS_JSON}" ]; then
    ERROR_MESSAGE=$(tail -n 20 "${EXTRACT_LOG}" | tr '\n' ' ' | sed 's/"/'\''/g')
    cat > "${METRICS_JSON}" <<EOF
{
  "model": "${MODEL_NAME}",
  "status": "failed",
  "started_at": "${START_ISO}",
  "ended_at": "${END_ISO}",
  "processed_clips": 0,
  "failed_clips": 0,
  "total_frames": 0,
  "total_time_sec": ${DURATION},
  "avg_fps": 0.0,
  "avg_inference_ms": 0.0,
  "output_dir": "${OUTPUT_DIR}",
  "error_message": "${ERROR_MESSAGE}"
}
EOF
  fi

  if [ "${EXIT_CODE}" -eq 0 ]; then
    STATUS="success"
  else
    STATUS="failed_or_partial"
  fi

  PROCESSED_CLIPS=$(python -c "import json; print(json.load(open('${METRICS_JSON}', encoding='utf-8')).get('processed_clips', 0))" 2>/dev/null || echo 0)
  log_global "[pose-compare] model=${MODEL_NAME} status=${STATUS} exit_code=${EXIT_CODE} started_at=${START_ISO} ended_at=${END_ISO} total_time_sec=${DURATION} processed_clips=${PROCESSED_CLIPS} log=${EXTRACT_LOG}"
done

python scripts/summarize_pose_models.py --runs "${RUNS_DIR}" >> "${GLOBAL_LOG}" 2>&1
log_global "[pose-compare] ended_at=$(date -Is)"
