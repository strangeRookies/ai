import json
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET


FALL_KEYWORDS = (
    "fall",
    "fallen",
    "falling",
    "fall_down",
    "faint",
    "syncope",
    "collapse",
    "collapsed",
    "실신",
    "낙상",
    "쓰러",
)

START_KEYS = ("start_frame", "startframe", "frame_start", "framestart", "start", "begin", "from")
END_KEYS = ("end_frame", "endframe", "frame_end", "frameend", "end", "stop", "to")
FRAME_KEYS = ("event_frame", "eventframe", "frame", "frame_no", "frameno", "frame_number", "framenumber", "number", "idx")
LABEL_KEYS = ("event_class", "eventclass", "class", "label", "action", "event", "name", "type", "category", "behavior")


def load_fall_intervals(annotation_path: Path | None) -> list[tuple[int, int]]:
    if annotation_path is None or not annotation_path.exists():
        return []
    if annotation_path.suffix.lower() == ".xml":
        return load_fall_intervals_xml(annotation_path)
    data = json.loads(annotation_path.read_text(encoding="utf-8"))
    intervals: list[tuple[int, int]] = []

    def add_interval(start: Any, end: Any) -> None:
        if start is None:
            return
        start_i = int(start)
        end_i = int(end if end is not None else start_i)
        if end_i < start_i:
            start_i, end_i = end_i, start_i
        intervals.append((start_i, end_i))

    if isinstance(data, dict):
        if "event_frame" in data:
            event = data["event_frame"]
            if isinstance(event, list) and len(event) == 2:
                add_interval(event[0], event[1])
            else:
                add_interval(event, event)
        for key in ("fall_frames", "fall_intervals", "fall_segments", "events"):
            value = data.get(key)
            if isinstance(value, list):
                for item in value:
                    if isinstance(item, dict):
                        label = str(item.get("label", item.get("event", "fall"))).lower()
                        if "fall" in label:
                            add_interval(item.get("start_frame", item.get("start")), item.get("end_frame", item.get("end")))
                    elif isinstance(item, list) and len(item) >= 2:
                        add_interval(item[0], item[1])
        for key in ("start_frame", "fall_start"):
            if key in data:
                add_interval(data.get(key), data.get("end_frame", data.get("fall_end")))
    elif isinstance(data, list):
        for item in data:
            if isinstance(item, dict):
                label = str(item.get("label", item.get("event", "fall"))).lower()
                if "fall" in label:
                    add_interval(item.get("start_frame", item.get("start")), item.get("end_frame", item.get("end")))
    return merge_intervals(intervals)


def load_fall_intervals_xml(annotation_path: Path) -> list[tuple[int, int]]:
    root = ET.parse(annotation_path).getroot()
    intervals: list[tuple[int, int]] = []
    fall_frames: list[int] = []

    for elem, values in iter_element_values(root):
        label = find_label(values)
        is_fall = is_fall_label(label) if label is not None else element_mentions_fall(elem)
        if not is_fall:
            continue

        start = first_int(values, START_KEYS)
        end = first_int(values, END_KEYS)
        event_frame = first_frame_value(values)

        if start is not None:
            intervals.append((start, end if end is not None else start))
        elif event_frame is not None:
            if isinstance(event_frame, tuple):
                intervals.append(event_frame)
            else:
                fall_frames.append(event_frame)

    intervals.extend(frames_to_intervals(sorted(set(fall_frames))))
    return merge_intervals(intervals)


def element_values(elem: ET.Element) -> dict[str, str]:
    values: dict[str, str] = {}
    for key, value in elem.attrib.items():
        values[normalize_key(key)] = value
    if elem.text and elem.text.strip():
        values[normalize_key(elem.tag)] = elem.text.strip()
    for child in list(elem):
        if child.text and child.text.strip():
            values[normalize_key(child.tag)] = child.text.strip()
        for key, value in child.attrib.items():
            values[f"{normalize_key(child.tag)}_{normalize_key(key)}"] = value
            values[normalize_key(key)] = value
    return values


def iter_element_values(elem: ET.Element, inherited: dict[str, str] | None = None):
    inherited = inherited or {}
    current = dict(inherited)
    current.update(element_values(elem))
    yield elem, current
    for child in list(elem):
        yield from iter_element_values(child, current)


def normalize_key(value: str) -> str:
    return "".join(ch for ch in value.lower() if ch.isalnum() or ch == "_")


def find_label(values: dict[str, str]) -> str | None:
    for key, value in values.items():
        if key in LABEL_KEYS or any(key.endswith(f"_{label_key}") for label_key in LABEL_KEYS):
            return str(value)
    for value in values.values():
        if is_fall_label(str(value)):
            return str(value)
    return None


def is_fall_label(value: str) -> bool:
    lowered = value.lower()
    return any(keyword in lowered for keyword in FALL_KEYWORDS)


def element_mentions_fall(elem: ET.Element) -> bool:
    tag = normalize_key(elem.tag)
    if is_fall_label(tag):
        return True
    return any(is_fall_label(str(value)) for value in elem.attrib.values())


def first_int(values: dict[str, str], keys: tuple[str, ...]) -> int | None:
    for key in keys:
        for candidate_key, value in values.items():
            if candidate_key == key or candidate_key.endswith(f"_{key}"):
                parsed = parse_int(value)
                if parsed is not None:
                    return parsed
    return None


def first_frame_value(values: dict[str, str]) -> int | tuple[int, int] | None:
    for key in FRAME_KEYS:
        for candidate_key, value in values.items():
            if candidate_key == key or candidate_key.endswith(f"_{key}"):
                ints = parse_ints(value)
                if len(ints) >= 2:
                    return (ints[0], ints[1])
                if len(ints) == 1:
                    return ints[0]
    return None


def parse_int(value: Any) -> int | None:
    ints = parse_ints(value)
    return ints[0] if ints else None


def parse_ints(value: Any) -> list[int]:
    text = str(value)
    numbers: list[int] = []
    current = ""
    for ch in text:
        if ch.isdigit() or (ch == "-" and not current):
            current += ch
        elif current:
            numbers.append(int(current))
            current = ""
    if current:
        numbers.append(int(current))
    return numbers


def frames_to_intervals(frames: list[int]) -> list[tuple[int, int]]:
    if not frames:
        return []
    intervals = []
    start = prev = frames[0]
    for frame in frames[1:]:
        if frame == prev + 1:
            prev = frame
        else:
            intervals.append((start, prev))
            start = prev = frame
    intervals.append((start, prev))
    return intervals


def merge_intervals(intervals: list[tuple[int, int]]) -> list[tuple[int, int]]:
    if not intervals:
        return []
    ordered = sorted(intervals)
    merged = [ordered[0]]
    for start, end in ordered[1:]:
        prev_start, prev_end = merged[-1]
        if start <= prev_end + 1:
            merged[-1] = (prev_start, max(prev_end, end))
        else:
            merged.append((start, end))
    return merged


def overlap_ratio(start: int, end: int, intervals: list[tuple[int, int]]) -> float:
    length = max(1, end - start + 1)
    overlap = 0
    for event_start, event_end in intervals:
        overlap += max(0, min(end, event_end) - max(start, event_start) + 1)
    return min(1.0, overlap / length)


def label_clip(
    start: int,
    end: int,
    intervals: list[tuple[int, int]],
    min_fall_overlap: float,
    normal_max_event_overlap: float,
    ambiguous_policy: str,
) -> int | None:
    ratio = overlap_ratio(start, end, intervals)
    if ratio >= min_fall_overlap:
        return 1
    if ratio <= normal_max_event_overlap:
        return 0
    if ambiguous_policy == "normal":
        return 0
    if ambiguous_policy == "fall":
        return 1
    return None
